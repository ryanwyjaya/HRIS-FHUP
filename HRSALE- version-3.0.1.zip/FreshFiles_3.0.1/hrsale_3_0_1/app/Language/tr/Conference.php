<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_events_calendar' => 'Etkinlik Takvimi',
'xin_event' => 'Etkinlik',
'xin_event_title' => 'Etkinlik Başlığı',
'xin_hr_event_date' => 'Etkinlik Tarihi',
'xin_hr_event_time' => 'Etkinlik Zamanı',
'xin_event_color' => 'Etkinlik Rengi',
'xin_hr_event_note' => 'Etkinlik Notu',
'xin_edit_event' => 'Etkinliği Düzenle',
'xin_hr_meeting_title' => 'Konferans Başlığı',
'xin_hr_meeting_date' => 'Konferans Tarihi',
'xin_hr_meeting_time' => 'Konferans Zamanı',
'xin_meeting_room' => 'Konferans Odası',
'xin_meeting_color' => 'Renk',
'xin_hr_meeting_note' => 'Not',
'xin_edit_meeting' => 'Konferansı Düzenle',
'xin_conference_calendar' => 'Konferans Takvimi',
'xin_conference' => 'Konferans',
];