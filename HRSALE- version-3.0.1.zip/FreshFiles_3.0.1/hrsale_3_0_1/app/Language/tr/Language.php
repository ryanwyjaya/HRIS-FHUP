<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_languages' => 'Diller',
'xin_language' => 'Dil',
'xin_flag' => 'İşaretle',
'xin_error_lang_name' => 'Dil adı alanı gerekli.',
'xin_error_lang_code' => 'Dil kodu alanı gerekli.',
'xin_error_lang_flag' => 'Dil bayrağı alanı gerekli.',
'xin_success_lang_added' => 'Dil eklendi.',
'xin_success_lang_updated' => 'Dil güncellendi.',
'xin_success_lang_deleted' => 'Dil silindi.',
'xin_success_lang_activated' => 'Dil etkinleştirildi.',
'xin_success_lang_deactivated' => 'Dil devre dışı bırakıldı.',
];