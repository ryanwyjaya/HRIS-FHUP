<?php

// override core en language system validation or define your own en language validation message
return [
'xin_dt_lengthMenu' => 'Hiển thị các mục _MENU_',
'xin_dt_zeroRecords' => 'Không có hồ sơ nào',
'xin_dt_info' => 'Hiển thị _START_ đến _END_ trong số _TOTAL_ bản ghi',
'xin_dt_infoEmpty' => 'Không có hồ sơ nào',
'xin_dt_infoFiltered' => '(được lọc từ tổng số bản ghi _MAX_)',
'xin_dt_search' => 'Tìm kiếm',
'dt_first' => 'Đầu tiên',
'dt_previous' => 'Trước đó',
'dt_next' => 'Tiếp theo',
'dt_last' => 'Cuối cùng'
];