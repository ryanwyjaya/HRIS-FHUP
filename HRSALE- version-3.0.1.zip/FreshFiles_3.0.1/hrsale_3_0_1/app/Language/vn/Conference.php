<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_events_calendar' => 'Lịch sự kiện',
'xin_event' => 'Sự kiện',
'xin_event_title' => 'Tiêu đề sự kiện',
'xin_hr_event_date' => 'Ngày sự kiện',
'xin_hr_event_time' => 'Thời gian sự kiện',
'xin_event_color' => 'Màu sự kiện',
'xin_hr_event_note' => 'Ghi chú Sự kiện',
'xin_edit_event' => 'Chỉnh sửa sự kiện',
'xin_hr_meeting_title' => 'Tiêu đề hội nghị',
'xin_hr_meeting_date' => 'Ngày hội nghị',
'xin_hr_meeting_time' => 'Giờ hội nghị',
'xin_meeting_room' => 'Phòng hội thảo',
'xin_meeting_color' => 'Màu',
'xin_hr_meeting_note' => 'Lưu ý',
'xin_edit_meeting' => 'Chỉnh sửa Hội nghị',
'xin_conference_calendar' => 'Lịch Hội nghị',
'xin_conference' => 'Hội nghị',
];