<?php

// override core en language system validation or define your own en language validation message
return [
'xin_dt_lengthMenu'=>'显示_MENU_条目',
'xin_dt_zeroRecords'=>'无可用记录',
'xin_dt_info'=>'显示_START_至_END_条记录（共_TOTAL_条记录）',
'xin_dt_infoEmpty'=>'无可用记录',
'xin_dt_infoFiltered'=>'（从_MAX_总记录中筛选）',
'xin_dt_search'=>'搜索',
'dt_first'=>'第一',
'dt_previous'=>'上一个',
'dt_next'=>'下一步',
'dt_last'=>'最后一个'
];