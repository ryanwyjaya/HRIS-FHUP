<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_languages'=>'语言能力',
'xin_language'=>'语',
'xin_flag'=>'标志',
'xin_error_lang_name'=>'语言名称字段为必填。',
'xin_error_lang_code'=>'语言代码字段为必填。',
'xin_error_lang_flag'=>'语言标记字段为必填。',
'xin_success_lang_added'=>'添加的语言',
'xin_success_lang_updated'=>'语言已更新。',
'xin_success_lang_deleted'=>'语言已删除。',
'xin_success_lang_activated'=>'语言已激活。',
'xin_success_lang_deactivated'=>'已停用语言。',
];