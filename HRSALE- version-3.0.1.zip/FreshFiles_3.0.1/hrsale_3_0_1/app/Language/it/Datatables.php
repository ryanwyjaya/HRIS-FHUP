<?php

// override core en language system validation or define your own en language validation message
return [
'xin_dt_lengthMenu' => 'Mostra voci _MENU_',
'xin_dt_zeroRecords' => 'Nessun record disponibile',
'xin_dt_info' => 'Visualizzazione da _START_ a _END_ di _TOTAL_ record',
'xin_dt_infoEmpty' => 'Nessun record disponibile',
'xin_dt_infoFiltered' => '(filtrato da _MAX_ record totali)',
'xin_dt_search' => 'Cerca',
'dt_first' => 'Primo',
'dt_previous' => 'Precedente',
'dt_next' => 'Avanti',
'dt_last' => 'Ultimo'
];