<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_events_calendar' => 'Calendario eventi',
'xin_event' => 'Evento',
'xin_event_title' => 'Titolo evento',
'xin_hr_event_date' => 'Data evento',
'xin_hr_event_time' => "ra dell'evento",
'xin_event_color' => 'Colore evento',
'xin_hr_event_note' => 'Nota evento',
'xin_edit_event' => 'Modifica evento',
'xin_hr_meeting_title' => 'Titolo della conferenza',
'xin_hr_meeting_date' => 'Data conferenza',
'xin_hr_meeting_time' => 'Conference Time',
'xin_meeting_room' => 'Sala conferenze',
'xin_meeting_color' => 'Colore',
'xin_hr_meeting_note' => 'Nota',
'xin_edit_meeting' => 'Modifica conferenza',
'xin_conference_calendar' => 'Conference Calendar',
'xin_conference' => 'Conferenza',
];