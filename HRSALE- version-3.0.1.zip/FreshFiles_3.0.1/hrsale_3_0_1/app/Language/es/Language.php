<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_languages' => 'Idiomas',
'xin_language' => 'Idioma',
'xin_flag' => 'Bandera',
'xin_error_lang_name' => 'El campo de nombre de idioma es obligatorio.',
'xin_error_lang_code' => 'El campo del código de idioma es obligatorio.',
'xin_error_lang_flag' => 'El campo de la bandera de idioma es obligatorio.',
'xin_success_lang_added' => 'Idioma agregado.',
'xin_success_lang_updated' => 'Idioma actualizado.',
'xin_success_lang_deleted' => 'Idioma eliminado.',
'xin_success_lang_activated' => 'Idioma activado.',
'xin_success_lang_deactivated' => 'Idioma desactivado.',
];