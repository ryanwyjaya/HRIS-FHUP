<?php

// override core en language system validation or define your own en language validation message
return [
'xin_dt_lengthMenu' => 'Mostrar _MENU_ entradas',
'xin_dt_zeroRecords' => 'Nenhum registro disponível',
'xin_dt_info' => 'Mostrando _START_ a _END_ de _TOTAL_ registros',
'xin_dt_infoEmpty' => 'Nenhum registro disponível',
'xin_dt_infoFiltered' => '(filtrado de _MAX_ registros totais)',
'xin_dt_search' => 'Pesquisa',
'dt_first' => 'Primeiro',
'dt_previous' => 'Anterior',
'dt_next' => 'Próximo',
'dt_last' => 'Último'
];