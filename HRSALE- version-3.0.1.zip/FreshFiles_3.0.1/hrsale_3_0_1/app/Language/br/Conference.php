<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
	'xin_events_calendar' => 'Events Calendar',
	'xin_event' => 'Event',
	'xin_event_title' => 'Event Title',
	'xin_hr_event_date' => 'Event Date',
	'xin_hr_event_time' => 'Event Time',
	'xin_event_color' => 'Event Color',
	'xin_hr_event_note' => 'Event Note',
	'xin_edit_event' => 'Edit Event',
	'xin_hr_meeting_title' => 'Conference Title',
	'xin_hr_meeting_date' => 'Conference Date',
	'xin_hr_meeting_time' => 'Conference Time',
	'xin_meeting_room' => 'Conference Room',
	'xin_meeting_color' => 'Color',
	'xin_hr_meeting_note' => 'Note',
	'xin_edit_meeting' => 'Edit Conference',
	'xin_conference_calendar' => 'Conference Calendar',
	'xin_conference' => 'Conference',
];